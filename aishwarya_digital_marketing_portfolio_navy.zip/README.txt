Aishwarya M. Digital Marketing Portfolio — Navy Blue Edition

Preview: open index.html in a browser.
Hosting: upload index.html and profile-photo.jpg into the same folder on your web host.
This edition uses a circular profile photo, navy-blue styling, and subtle animations.
GitHub has been removed from the contact section.
Update any experience dates or details as needed before publishing.
